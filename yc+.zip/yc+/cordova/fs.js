let fs = { }
fs .ispromise = fs .promise = fs .istrue = function ( ) {
	
}

fs .writeFile = function ( name , data , call ) {
	var type = window.TEMPORARY;
	var size = data .replace( /[^\u0000-\u00ff]/g , "aaa" )
	window.requestFileSystem(type, size, successCallback, errorCallback)
	function successCallback ( fs ) {
   	fs .root .getFile( name , {create: true}, function(fileEntry) {
   		fileEntry.createWriter(function(fileWriter) {
   			fileWriter.onwriteend = function(e) {
   				call ( e )
   			}
   			fileWriter.onerror = function(e) {
   				call ( null , e )
   			};
   			var blob = new Blob([data], {type: 'text/plain'});
   			fileWriter.write(blob);
   		}, errorCallback);
     }, errorCallback);
   }
   function errorCallback(error) {
   	call ( error )
   }
}
function readFile() {
   var type = window.TEMPORARY;
   var size = 5*1024*1024;

   window.requestFileSystem(type, size, successCallback, errorCallback)

   function successCallback(fs) {

      fs.root.getFile('log.txt', {}, function(fileEntry) {

         fileEntry.file(function(file) {
            var reader = new FileReader();

            reader.onloadend = function(e) {
               var txtArea = document.getElementById('textarea');
               txtArea.value = this.result;
            };

            reader.readAsText(file);

         }, errorCallback);

      }, errorCallback);
   }

   function errorCallback(error) {
      alert("ERROR: " + error.code)
   }
	
}